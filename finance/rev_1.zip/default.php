<script type='text/javascript'>
	$(function() {
		$('#sub-menu').show('drop', 1000);
	});
</script>
<div id='sub-menu' align='center'>
		<div id='menu' align='left'>
			<ul>
				<li id='inventory-search-item'>
					<img src='../lib/img/menu-icons/cash_reg.png' style='float:left;margin-right:8px;'/>
					Cash Register
				</li>
				<li id='inventory-manage-inventory'>
					<img src='../lib/img/menu-icons/forecast.png' style='float:left;margin-right:8px;'/>
					Forecast Financial Status 
				</li>
				<li id='inventory-back'> 
					<img src='../lib/img/small/back.png' style='float:left;margin-right:8px;'/>
					Go back to Dashboard
				</li>
			</ul>
		</div>
		<div id='sub-menu-text' align='left'>
			<img src='../lib/img/icon/financial.png' style='float:left'/>
				<div class='sub-menu-text-main'>
					inventory
				</div>
				inventory management sub-menu				
		</div>
	</div>
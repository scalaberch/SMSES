<script type='text/javascript'>
	$(function() {
		$('#content-container').show('drop', 1000);
	});
</script>
<div id='content-container' align='center'>
	<div id='content' align='left' class='rounded-corners'>
		<div id='content-title'>
			View Item Information
		</div>
		<div id='content-menu-buttons'>
			<a href='?'>Back to Inventory Menu&nbsp </a>
			<ul class='ui-widget ui-helper-clearfix'>
				<li></li>
				<!--
				<li>
					<a href='?' class='button'>
						<span class="ui-icon ui-icon-circle-triangle-w"></span>
					</a>
				</li>
				-->
			</ul>
		</div>
		
		
	</div>
</div>

<!-- jQuery Dialogs -->

<!-- End jQuery Dialog -->
<div id='content-container' align='center'>
	<div id='content' align='left' class='rounded-corners'>
		<div id='content-title'>
			Suppliers' List
		</div>
		<div id='content-menu-buttons'>
			<ul class='ui-widget ui-helper-clearfix'>
				<li><a href='#'>Search for Supplier&nbsp </a></li>
				<li><a href='#'>Add New Supplier&nbsp </a></li>
				<li><a href='#'>Back to Inventory Menu&nbsp </a></li>
				<!--
				<li>
					<a href='?' class='button'>
						<span class="ui-icon ui-icon-circle-triangle-w"></span>
					</a>
				</li>
				-->
			</ul>
		</div>
		
		
		<div id='content-table'>
			<div id='content-table-nav'>
				<a href='#prev'>Previous</a> | <a href='#next'>Next</a>
			</div>
			<table cellspacing=0>
				<th> Number </th><th> Supplier Name </th><th> Supplier Address</th><th> Supplier Contact </th>
				<tr>
					<td> 1234 </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> 3913 </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> 3332 </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>	
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
				<tr>
					<td> fsdk </td><td> fsdk </td><td> fsdk </td><td> fsdk </td>
				</tr>
			</table>
			<div id='table-info'>
				Showing 12 suppliers (1-12) in total of 450 suppliers.
			</div>
		</div>
	</div>
</div>

<!-- jQuery Dialogs -->

<!-- End jQuery Dialog -->